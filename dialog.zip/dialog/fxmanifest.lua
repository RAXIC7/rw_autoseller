fx_version 'cerulean'

game 'gta5'

client_script 'client.lua'

ui_page 'html/ui.html'

files {
	'html/ui.html',
	'html/listener.js',
	'html/css/*.css',
	'html/images/*.png',
	'html/css/fonts/*.ttf'
}
